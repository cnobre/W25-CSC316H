/* main JS file */

console.log("Hello JS world!");