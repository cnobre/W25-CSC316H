

// Variables to store trial results
let trialResults = [];

// populate trialResults with historicalData
trialResults = historicalData;

// initialize test & matrix visualizations
let myResultsMatrixVis = new ResultsMatrixVis("resultsMatrixVisContainer", historicalData)
